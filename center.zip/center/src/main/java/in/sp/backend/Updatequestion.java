package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/update")
public class Updatequestion extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter pw = response.getWriter();

        // paperId, languageId, questionNo, choiceA, choiceB, choiceC, choiceD, correctChoice
        String paperid = request.getParameter("paperId");
        String languageid = request.getParameter("languageId");
        String questionno = request.getParameter("questionNoToUpdate");
        String question = request.getParameter("question");
        String a = request.getParameter("newChoiceA");
        String b = request.getParameter("newChoiceB");
        String c = request.getParameter("newChoiceC");
        String d = request.getParameter("newChoiceD");
        String ans = request.getParameter("newCorrectChoice");
        int pid = Integer.parseInt(paperid);
        int lid = Integer.parseInt(languageid);
        int qno = Integer.parseInt(questionno);

        String url = "jdbc:postgresql://localhost:5432/DBMS_PROJECT";
        String user = "postgres";
        String password = "admin";

        Connection connection = null;

        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(url, user, password);

            System.out.println("Connected to the database!");

            // Update the question_set table
            String updateQuery = "UPDATE question_set SET que_no=?, question =?, choice_a=?, choice_b=?, choice_c=?, choice_d=?, correct_choice=? WHERE paper_id=? AND language_id=? AND que_no=?";
            try (PreparedStatement ps = connection.prepareStatement(updateQuery)) {
                ps.setInt(1, qno);
                ps.setString(2,question);
                ps.setString(3, a);
                ps.setString(4, b);
                ps.setString(5, c);
                ps.setString(6, d);
                ps.setString(7, ans);
                ps.setInt(8, pid);
                ps.setInt(9, lid);
                ps.setInt(10, qno);

                int rowsUpdated = ps.executeUpdate();

                if (rowsUpdated > 0) {
                    System.out.println("Question updated successfully!");
                } else {
                    System.out.println("No questions were updated!");
                }
            }
//             request.setAttribute("paperid",paperid);
//             request.setAttribute("lid", languageid);
            // Forward the request to paper.jsp
            //request.getRequestDispatcher("/modify_paper.jsp").forward(request, response);
            pw.print("Succesfully Updated...!!");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            pw.println("Error: " + e.getMessage()); // Include error information in the HTTP response
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                    pw.println("Error closing connection: " + e.getMessage());
                }
            }
        }
    }
}
