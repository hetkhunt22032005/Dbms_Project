
package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/issue")
public class issue extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // Extract student ID from the request parameter
        int studentId = Integer.parseInt(req.getParameter("s_id"));

        try {
            // Load the PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");

            // Establish a database connection
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DBMS_PROJECT", "postgres", "admin");

            // Prepare the SQL statement to update Main_center status for the given student ID
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE Main_center SET Status = 1 WHERE ID = ?");
            preparedStatement.setInt(1, studentId);

            // Execute the update statement and get the number of rows affected
            int rowsAffected = preparedStatement.executeUpdate();
            
            PrintWriter out=resp.getWriter();
            out.println("<html><head><title>Issue Report</title>");
            out.println("<style>");
            out.println("body { background-color: #e6ffe6; text-align: center; margin: 0; padding: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; font-family: 'Arial', sans-serif;}");
            out.println("h2 { color: #4caf50; margin-top: 50px; }");
            out.println("</style>");
            out.println("</head><body>");
            out.println("</body></html>");

            if (rowsAffected > 0) {

            	out.println("<h2>Issue reported successfully for student ID: " + studentId + "</h2>");
    

             
            } else {
            	 //out.println("h2 { color: #FF0000; margin-top: 50px; }");
            	 out.println("<html><head><title>Issue Report</title>");
                 out.println("<style>");
                 out.println("body { background-color: #e6ffe6; text-align: center; margin: 0; padding: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; font-family: 'Arial', sans-serif;}");
                 out.println("h2 { color: #FF0000; margin-top: 50px; }");
                 out.println("</style>");
                 out.println("</head><body>");
                 out.println("</body></html>");
            	out.println("<h2>Failed to report issue. Student ID not found: " + studentId + "</h2>");
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Handle the exception appropriately in a real application
        }
    }
}