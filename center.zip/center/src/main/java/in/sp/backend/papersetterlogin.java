package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@SuppressWarnings("serial")
@WebServlet("/pslogin")
public class papersetterlogin extends HttpServlet{
	protected void service(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	{    @SuppressWarnings("unused")
		String id=req.getParameter("id");
	    int id1=Integer.parseInt(id);
		String password1=req.getParameter("password");
		PrintWriter pw=res.getWriter();
		
		 String url = "jdbc:postgresql://localhost:5432/DBMS_PROJECT";
	        String user = "postgres";
	        String password = "admin";

	     
	        Connection connection = null;

	        try {
	          
	            Class.forName("org.postgresql.Driver");

	           
	            connection = DriverManager.getConnection(url, user, password);

	            

	            System.out.println("Connected to the database!");
	            
	            PreparedStatement ps = null;
	    		try {
	    			 ps=connection.prepareStatement("select * from paper_setter");
	    			
	    		} catch (SQLException e) {
	    			pw.println(e);
	    			e.printStackTrace();
	    		}
	    		ResultSet rs=null;
	        	try {
	    			rs=ps.executeQuery();
	    		} catch (SQLException e) {
	    			pw.println(e);
	    			e.printStackTrace();
	    		}
                while(rs.next())
                {
                	if(id1==rs.getInt("paper_setter_id") && password1.equals(rs.getString("login_password")))
                	{   
                		
        				
                		int paperid=rs.getInt("paper_id");
                		
                		HttpSession psc=req.getSession();
        				psc.setAttribute("p_id", rs.getInt("paper_id"));
        				 
                		PreparedStatement ps1=connection.prepareStatement("select language_id from paper_lang where paper_id=?");
                		ps1.setInt(1, paperid);
                		ResultSet rs1=ps1.executeQuery();
                		String fullname=rs.getString("full_name");
                		String qualification=rs.getString("qualification");
                		String collage=rs.getString("college_university");
                		String emailid=rs.getString("email_id");
                		while(rs1.next())
                		{
                		int lid=rs1.getInt("language_id");
                		
                		req.setAttribute("fullname", fullname);
                      req.setAttribute("id", id);
                      req.setAttribute("password", password1);
                      req.setAttribute("emailid", emailid);
                      req.setAttribute("collage",collage );
                      req.setAttribute("qualification", qualification);
                      req.setAttribute("paperid", paperid);
                      req.setAttribute("lid", lid);
                      RequestDispatcher rd=req.getRequestDispatcher("/profile.jsp");
                      rd.forward(req, res);
                		}
                	}
                	
                }
	        	
				//.println("Your password or id is incorrect");
				req.setAttribute("errorMessage", "Your ID or password is incorrect");

				RequestDispatcher rd1=req.getRequestDispatcher("/papersetterlogin.jsp");
                rd1.forward(req, res);
	        }
	         catch (ClassNotFoundException e) {
	        	 pw.println(e);
	            System.err.println("Could not find the PostgreSQL JDBC driver. Include it in your library path!");
	          
	        } catch (SQLException e) {
                pw.println(e);
	        	System.err.println("Failed to connect to the database!");
	           
	          
	        } finally {
	           
	            if (connection != null) {
	                try {
	                    connection.close();
	                } catch (SQLException e) {
	                   
	                }
	            }
	        }
		
		
		
		
	}

}
