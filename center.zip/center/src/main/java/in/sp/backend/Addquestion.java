package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/add")
public class Addquestion extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter pw = response.getWriter();
        try {
            // paperId, languageId, questionNo, choiceA, choiceB, choiceC, choiceD, correctChoice
            String paperid = request.getParameter("paperId");
            String languageid = request.getParameter("languageId");
            String questionno = request.getParameter("questionNo");
            String question = request.getParameter("question");
            String a = request.getParameter("choiceA");
            String b = request.getParameter("choiceB");
            String c = request.getParameter("choiceC");
            String d = request.getParameter("choiceD");
            String ans = request.getParameter("correctChoice");
            int pid = Integer.parseInt(paperid);
            int lid = Integer.parseInt(languageid);
            int qno = Integer.parseInt(questionno);
            String url = "jdbc:postgresql://localhost:5432/DBMS_PROJECT";
            String user = "postgres";
            String password = "admin";

            Connection connection = null;

            try {
                Class.forName("org.postgresql.Driver");
                connection = DriverManager.getConnection(url, user, password);

                System.out.println("Connected to the database!");
                PreparedStatement ps = connection.prepareStatement("insert into question_set values(?,?,?,?,?,?,?,?,?)");
                ps.setInt(1, pid);
                ps.setInt(2, lid);
                ps.setInt(3, qno);
                ps.setString(4, question);
                ps.setString(5, a);
                ps.setString(6, b);
                ps.setString(7, c);
                ps.setString(8, d);
                ps.setString(9, ans); // Corrected the index to 8

                // Execute the insert query
                ps.executeUpdate();
                PrintWriter out=response.getWriter();
                out.print("Succesfully Added...!!");
            } catch (ClassNotFoundException e) {
                pw.println(e);
                System.err.println("Could not find the PostgreSQL JDBC driver. Include it in your library path!");
            } catch (SQLException e) {
                pw.println(e);
                System.err.println("Failed to connect to the database!");
            } finally {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        pw.println(e);
                    }
                }
            }
        } catch (Exception e) {
            pw.println(e);
        }
    }
}
