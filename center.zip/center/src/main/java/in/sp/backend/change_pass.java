package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/change_pas")
public class change_pass extends HttpServlet{
		
	 @Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		 System.out.println("ohh");
		 HttpSession stu = req.getSession();
    	 int id = (int) stu.getAttribute("id_key");
    	 String pass = (String) req.getParameter("password");
    	 System.out.println(pass);
    	 try {
        	 
             Class.forName("org.postgresql.Driver");
             System.out.println("driver class loaded 111");
             Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DBMS_PROJECT", "postgres", "admin");
             System.out.println("done");
          
         
         PreparedStatement ps = con.prepareStatement("update student set password = ? where id = ?");
         System.out.println("done");
         ps.setString(1, pass);
         System.out.println("done");
         ps.setInt(2,id);
          
         int check = ps.executeUpdate();
         System.out.println("done");
         PrintWriter pr = res.getWriter();
         System.out.println("done");
         if(check>0)
         {
        	res.setContentType("text/html");
         	pr.println("password changed");
         	RequestDispatcher rd = req.getRequestDispatcher("/change_pass.jsp");
         	rd.include(req, res);
        	 
         }
         else
         {
        	 pr.println("password not changed");
         }
     } catch (Exception e) {
         e.printStackTrace();
     }
	}
}
