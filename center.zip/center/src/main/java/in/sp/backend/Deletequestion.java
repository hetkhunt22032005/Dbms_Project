package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/delete")
public class Deletequestion extends HttpServlet {
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter pw = response.getWriter();
        try {
            // paperId, languageId, questionNo, choiceA, choiceB, choiceC, choiceD, correctChoice
            String paperid = request.getParameter("paperId");
            String languageid = request.getParameter("languageId");
            String questionno = request.getParameter("questionNoToDelete");

            int pid = Integer.parseInt(paperid);
            int lid = Integer.parseInt(languageid);
            int qno = Integer.parseInt(questionno);
            String url = "jdbc:postgresql://localhost:5432/DBMS_PROJECT";
            String user = "postgres";
            String password = "admin";

            Connection connection = null;

            try {
                Class.forName("org.postgresql.Driver");
                connection = DriverManager.getConnection(url, user, password);

                System.out.println("Connected to the database!");
                PreparedStatement ps = connection.prepareStatement("delete from question_set where paper_id=? and language_id=? and que_no=?");
                ps.setInt(1, pid);
                ps.setInt(2, lid);
                ps.setInt(3, qno);
                ps.executeUpdate(); // Execute the delete query
                //request.setAttribute("paperid",paperid);
                //request.setAttribute("lid", languageid);
                // Forward the request to paper.jsp
                //request.getRequestDispatcher("modify_paper.jsp").forward(request, response);
                pw.println("Succesfully Deleted...!!");
            } catch (ClassNotFoundException e) {
                System.err.println("Could not find the PostgreSQL JDBC driver. Include it in your library path!");
            } catch (SQLException e) {
                System.err.println("Failed to connect to the database!");
            } finally {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        // Handle closing connection exception if needed
                    }
                }
            }
        } catch (Exception e) {
            pw.println(e);
        }
    }
}
