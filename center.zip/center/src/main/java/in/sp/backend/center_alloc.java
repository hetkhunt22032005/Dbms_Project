  package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/center_alloc")
public class center_alloc extends HttpServlet {

    
	@Override
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		 

		//HttpSession stu = req.getSession();
		 
		
        String city = req.getParameter("city");
        String state = req.getParameter("state");
        String country = req.getParameter("country");
        System.out.println("ok");

        try {
        	HttpSession stu = req.getSession(); 
        	int id = (int) stu.getAttribute("id_key");
        	 
                Class.forName("org.postgresql.Driver");
                System.out.println("driver class loaded");
                Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DBMS_PROJECT", "postgres", "admin");
                System.out.println("done");
             
            
            PreparedStatement ps = con.prepareStatement("select center_id from center natural join city natural join district natural join state natural join country where city = ? and state = ? and country = ? and ((center_id in (select center_id from adv_center group by center_id having count (id) <= 2) or center_id not in(select distinct(center_id) from adv_center) ))");
            System.out.println("done");
            ps.setString(1,city);
            System.out.println("done");
            ps.setString(2, state);
            ps.setString(3, country);
            System.out.println("done");
            ResultSet rs = ps.executeQuery();
            System.out.println("done");
            PrintWriter pr = res.getWriter();
            System.out.println("done");
            if (rs.next()) {
           	 	
            	PreparedStatement ps2 = con.prepareStatement("select * from adv_center where id =?");
            	ps2.setInt(1,id);
            	ResultSet k1 = ps2.executeQuery();
            	if(k1.next())
            	{
            		res.setContentType("text/html");
                   	pr.println("Center Already Allocated");
                   	RequestDispatcher rd = req.getRequestDispatcher("/dd.jsp");
                   	rd.include(req, res);
            	}
            	else
            	{
            	PreparedStatement ps1 = con.prepareStatement("insert into adv_center values (?,?)");
            	ps1.setInt(1,id);
            	int r = (int)rs.getInt("center_id");
            	ps1.setInt(2,r );
            	int k = ps1.executeUpdate();
            	res.setContentType("text/html");
               	pr.println("Center Allocated");
               	RequestDispatcher rd = req.getRequestDispatcher("/dd.jsp");
               	rd.include(req, res);
          System.out.println("done");
            	}
           	 
           } else {
           	res.setContentType("text/html");
           	pr.println("center not available");
           	RequestDispatcher rd = req.getRequestDispatcher("/dd.jsp");
           	rd.include(req, res);
           }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

 