package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class login extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		resp.setContentType("text/html");
		int myid=Integer.parseInt(req.getParameter("id"));
		String mypssword=req.getParameter("password");
		
		PrintWriter out=resp.getWriter();
		try
		{
			Class.forName("org.postgresql.Driver");
			Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/DBMS_PROJECT","postgres","admin");
			
			PreparedStatement ps= con.prepareStatement("select * from center where Admin_ID=? and Admin_Password=?  ");
			
			ps.setInt(1,myid);
			ps.setString(2, mypssword);
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
				HttpSession session=req.getSession();
				session.setAttribute("center_id", rs.getInt("Center_ID"));
				
				RequestDispatcher rd=req.getRequestDispatcher("/fpage.jsp");
				rd.include(req, resp);
			}
			else {
			    out.println("<div style=\"color: #ff0000; text-align: center; margin-top: 10px;\">");
			    out.println("<strong>Error:</strong> Incorrect ID or password. Please try again.");
			    out.println("</div>");

			    RequestDispatcher rd = req.getRequestDispatcher("/login.jsp");
			    rd.include(req, resp);
			}

		
		}
		catch(Exception e) {
		    out.println("<div style=\"color: #ff0000; text-align: center; margin-top: 10px;\">");
		    out.println("<strong>Error:</strong> An unexpected error occurred. Please try again later.");
		    out.println("</div>");

		    // Log the exception
		    out.print("An error occurred during login processing"+ e);
		}
		
	}

}
