 package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@WebServlet("/student_login")
public class demo extends HttpServlet {

    
	@Override
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String id = req.getParameter("id");
        int id2 =Integer.parseInt(id);
        String password = req.getParameter("password");
        System.out.println("ok");

        try {
        	 
                Class.forName("org.postgresql.Driver");
                System.out.println("driver class loaded");
                Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DBMS_PROJECT", "postgres", "admin");
                System.out.println("done");
             
            
            PreparedStatement ps = con.prepareStatement("select * from student where id = ? and password = ?");
            System.out.println("done");
            ps.setInt(1, id2);
            System.out.println("done");
            ps.setString(2, password);
            System.out.println("done");
            ResultSet rs = ps.executeQuery();
            System.out.println("done");
            PrintWriter pr = res.getWriter();
            System.out.println("done");
            if (rs.next()) {
            	//pr.print("suc");
            	//System.out.println("done");
            	//req.setAttribute("name_key",rs.getString("first_name"));
            	HttpSession stu = req.getSession();
            	stu.setAttribute("id_key",rs.getInt("id"));
            	RequestDispatcher rd = req.getRequestDispatcher("/Student.jsp");
                 rd.forward(req, res);
            } else {
            	res.setContentType("text/html");
            	pr.println("Incorrect id or password");
            	RequestDispatcher rd = req.getRequestDispatcher("/Student_Login.html");
            	rd.include(req, res);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
