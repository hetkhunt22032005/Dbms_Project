package in.sp.backend;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/ad_ann_check")
public class adannouncement extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        PrintWriter out = response.getWriter();
        Connection con = null;

        try {
            Class.forName("org.postgresql.Driver");

            String url = "jdbc:postgresql://localhost:5432/DBMS_PROJECT";
            String username = "postgres";
            String password = "admin";

            con = DriverManager.getConnection(url, username, password);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            out.print("<html><head><title>Error</title></head><body style='background-color:#ffe6e6;text-align:center;'>");
            out.print("<h2 style='color:red;margin-top:50px;'>PostgreSQL JDBC driver not found</h2>");
            out.print("</body></html>");
            return;
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("<html><head><title>Error</title></head><body style='background-color:#ffe6e6;text-align:center;'>");
            out.print("<h2 style='color:red;margin-top:50px;'>Connection to the database failed</h2>");
            out.print("</body></html>");
            return;
        }

        String announcement = request.getParameter("announcement");
        String status = request.getParameter("status");

        try {
            int st = Integer.parseInt(status);
            PreparedStatement ps = con.prepareStatement("insert into Announcement values(?, ?)");
            ps.setString(1, announcement);
            ps.setInt(2, st);

            int upd = ps.executeUpdate();

            if (upd > 0) {
                out.print("<html><head><title>Success</title>");
                out.print("<style>body { background-color: #e6ffe6; text-align: center; } h2 { color: #4caf50; margin-top: 50px; font-family: 'Arial', sans-serif; }</style>");
                out.print("</head><body>");
                out.print("<h2>Announce Successfully</h2>");
                out.print("</body></html>");
            } else {
                out.print("<html><head><title>Error</title></head><body style='background-color:#ffe6e6;text-align:center;'>");
                out.print("<h2 style='color:red;margin-top:50px;'>Announcement submission failed</h2>");
                out.print("</body></html>");
            }
        } catch (NumberFormatException e) {
            out.print("<html><head><title>Error</title></head><body style='background-color:#ffe6e6;text-align:center;'>");
            out.print("<h2 style='color:red;margin-top:50px;'>Invalid status format</h2>");
            out.print("</body></html>");
        } catch (SQLException e) {
            out.print("<html><head><title>Error</title></head><body style='background-color:#ffe6e6;text-align:center;'>");
            out.print("<h2 style='color:red;margin-top:50px;'>Database error: " + e.getMessage() + "</h2>");
            out.print("</body></html>");
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
