   package in.sp.backend;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/correction")
public class correction  extends HttpServlet {

    
	@Override
    protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
         
		
		String que = req.getParameter("que_no");
		int que2 = Integer.parseInt(que);
        String option = req.getParameter("selected_Option");
        String cor_option = req.getParameter("correct_Option");
        PrintWriter pr = res.getWriter();
         

        try {
        	HttpSession stu = req.getSession();
    		int id = (int)stu.getAttribute("id_key");
                Class.forName("org.postgresql.Driver");
                System.out.println("driver class loaded");
                Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/DBMS_PROJECT", "postgres", "admin");
                System.out.println("done");
             
            
            PreparedStatement ps = con.prepareStatement("select * from given natural join question_set where correct_choice = '"+option+"' and id = '"+id+"'");
             
            ResultSet rs = ps.executeQuery();
            if(option.equals(cor_option))
    		{
    			System.out.println("muaa");
    			res.setContentType("text/html");
    			pr.println("given option and correct option is same");
    	
    			RequestDispatcher rd = req.getRequestDispatcher("/corr_query.jsp");
    			rd.include(req, res);
    	    }
    		else if(rs.next()) {
    			PreparedStatement ps1 = con.prepareStatement("INSERT INTO query SELECT id, paper_id, language_id, que_no, 0, ? FROM given NATURAL JOIN question_set WHERE que_no = ? AND id = ?");
    			ps1.setString(1, cor_option);
    			ps1.setInt(2, que2);
    			ps1.setInt(3, id);
    			int k = ps1.executeUpdate();

    	 
    	res.setContentType("text/html");
    	pr.println("query added succesfully");
    	RequestDispatcher rd = req.getRequestDispatcher("/Student.jsp");
         rd.include(req, res);
    } else {
    	System.out.println("muaa3");
    	res.setContentType("text/html");
    	pr.println("Incorrect query");
    	RequestDispatcher rd = req.getRequestDispatcher("/corr_query.jsp");
    	rd.include(req, res);
    }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
